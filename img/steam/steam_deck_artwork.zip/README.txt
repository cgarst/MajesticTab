MajesticTab - Steam Big Picture & Steam Deck Custom Artwork
===========================================================
Custom artwork assets for adding MajesticTab to Steam / Steam Deck Big Picture mode.

Files included:
- grid_600x900.png    -> Steam Capsule / Portrait Grid (Library view)
- grid_920x430.png    -> Steam Banner / Wide Grid (Recent games view)
- hero_3840x1240.png  -> Steam Hero Background (Game details header)
- logo_1280x720.png   -> Steam Logo Overlay (Transparent title art)
- icon_512x512.png    -> Steam shortcut icon

How to apply custom artwork in Steam Desktop / Steam Deck:
1. Open Steam and right-click MajesticTab in your Library (or click the Settings gear icon).
2. Choose "Properties" -> click the icon square to select "icon_512x512.png".
3. Right-click the game hero background -> "Set Custom Background" -> choose "hero_3840x1240.png".
4. Right-click the game logo area -> "Set Custom Logo" -> choose "logo_1280x720.png".
5. In your Library grid view, right-click the MajesticTab poster -> "Manage" -> "Set custom artwork" -> choose "grid_600x900.png" (and "grid_920x430.png" when prompted for wide grid).
